package org.example;

public class Lab7V2 {

    public static double averageMatrix(double[][] matrix) {
        if (matrix == null || matrix.length == 0 || matrix[0].length == 0) {
            return 0.0;
        }

        double sum = 0.0;
        int count = 0;

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                sum += matrix[i][j];
                count++;
            }
        }

        return sum / count;
    }

    public static double[] minInColumns(double[][] matrix) {
        if (matrix == null || matrix.length == 0 || matrix[0].length == 0) {
            return new double[0];
        }

        int cols = matrix[0].length;
        double[] minValues = new double[cols];

        for (int j = 0; j < cols; j++) {
            minValues[j] = Double.MAX_VALUE;
        }

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < cols; j++) {
                if (matrix[i][j] < minValues[j]) {
                    minValues[j] = matrix[i][j];
                }
            }
        }

        return minValues;
    }

    public static int columnWithMinSum(double[][] matrix) {
        if (matrix == null || matrix.length == 0 || matrix[0].length == 0) {
            return -1;
        }

        int cols = matrix[0].length;
        double[] columnSums = new double[cols];

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < cols; j++) {
                columnSums[j] += matrix[i][j];
            }
        }

        double minSum = columnSums[0];
        int minColumn = 0;
        for (int j = 1; j < cols; j++) {
            if (columnSums[j] < minSum) {
                minSum = columnSums[j];
                minColumn = j;
            }
        }

        return minColumn;
    }
}