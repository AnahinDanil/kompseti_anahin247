import org.example.Lab7V2;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Lab7V2Test {


    @Test
    void testAverageMatrix_TypicalCase() {
        double[][] matrix = {
                {1.0, 2.0, 3.0},
                {4.0, 5.0, 6.0},
                {7.0, 8.0, 9.0}
        };
        assertEquals(5.0, Lab7V2.averageMatrix(matrix), 0.0001);
    }

    @Test
    void testAverageMatrix_WithNegatives() {
        double[][] matrix = {
                {-1.0, -2.0, -3.0},
                {-4.0, -5.0, -6.0}
        };
        assertEquals(-3.5, Lab7V2.averageMatrix(matrix), 0.0001);
    }

    @Test
    void testAverageMatrix_SingleElement() {
        double[][] matrix = {{42.0}};
        assertEquals(42.0, Lab7V2.averageMatrix(matrix), 0.0001);
    }

    @Test
    void testAverageMatrix_EmptyMatrix() {
        double[][] matrix = {};
        assertEquals(0.0, Lab7V2.averageMatrix(matrix), 0.0001);
    }

    @Test
    void testAverageMatrix_NullMatrix() {
        assertEquals(0.0, Lab7V2.averageMatrix(null), 0.0001);
    }


    @Test
    void testMinInColumns_TypicalCase() {
        double[][] matrix = {
                {3.0, 8.0, 1.0},
                {5.0, 2.0, 7.0},
                {9.0, 4.0, 6.0}
        };
        double[] expected = {3.0, 2.0, 1.0};
        assertArrayEquals(expected, Lab7V2.minInColumns(matrix), 0.0001);
    }

    @Test
    void testMinInColumns_WithNegatives() {
        double[][] matrix = {
                {-5.0, -2.0, -8.0},
                {-1.0, -9.0, -3.0}
        };
        double[] expected = {-5.0, -9.0, -8.0};
        assertArrayEquals(expected, Lab7V2.minInColumns(matrix), 0.0001);
    }

    @Test
    void testMinInColumns_SingleRow() {
        double[][] matrix = {{10.0, 20.0, 30.0, 40.0}};
        double[] expected = {10.0, 20.0, 30.0, 40.0};
        assertArrayEquals(expected, Lab7V2.minInColumns(matrix), 0.0001);
    }

    @Test
    void testMinInColumns_SingleColumn() {
        double[][] matrix = {
                {5.0},
                {3.0},
                {8.0},
                {1.0}
        };
        double[] expected = {1.0};
        assertArrayEquals(expected, Lab7V2.minInColumns(matrix), 0.0001);
    }

    @Test
    void testMinInColumns_EmptyMatrix() {
        double[][] matrix = {};
        double[] expected = {};
        assertArrayEquals(expected, Lab7V2.minInColumns(matrix), 0.0001);
    }


    @Test
    void testColumnWithMinSum_TypicalCase() {
        double[][] matrix = {
                {1.0, 4.0, 2.0},
                {2.0, 5.0, 3.0},
                {3.0, 6.0, 1.0}
        };
        // Суммы столбцов: 6, 15, 6 -> минимальная у столбцов 0 и 2, возвращает первый найденный
        assertEquals(0, Lab7V2.columnWithMinSum(matrix));
    }

    @Test
    void testColumnWithMinSum_WithNegatives() {
        double[][] matrix = {
                {-1.0, -5.0, -2.0},
                {-3.0, -4.0, -1.0},
                {-2.0, -6.0, -3.0}
        };
        assertEquals(1, Lab7V2.columnWithMinSum(matrix));
    }

    @Test
    void testColumnWithMinSum_SingleRow() {
        double[][] matrix = {{10.0, 3.0, 8.0, 1.0}};
        assertEquals(3, Lab7V2.columnWithMinSum(matrix));
    }

    @Test
    void testColumnWithMinSum_SingleColumn() {
        double[][] matrix = {
                {5.0},
                {3.0},
                {8.0}
        };
        assertEquals(0, Lab7V2.columnWithMinSum(matrix));
    }

    @Test
    void testColumnWithMinSum_EmptyMatrix() {
        double[][] matrix = {};
        assertEquals(-1, Lab7V2.columnWithMinSum(matrix));
    }
}