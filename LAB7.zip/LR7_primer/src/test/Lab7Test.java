import org.example.Lab7;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Lab7Test {

    @Test
    void testTypicalCase() {
        int[][] matrix = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };
        assertEquals(2, Lab7.rowWithMaxSum(matrix)); // Суммы: 6, 15, 24
    }

    @Test
    void testFirstRowMaxSum() {
        int[][] matrix = {
                {10, 20},
                {1, 2},
                {3, 4}
        };
        assertEquals(0, Lab7.rowWithMaxSum(matrix)); // Суммы: 30, 3, 7
    }

    @Test
    void testNegativeValues() {
        int[][] matrix = {
                {-5, -5},
                {-10, -10},
                {-1, -2}
        };
        assertEquals(2, Lab7.rowWithMaxSum(matrix)); // Суммы: -10, -20, -3
    }

    @Test
    void testSingleRow() {
        int[][] matrix = {
                {100}
        };
        assertEquals(0, Lab7.rowWithMaxSum(matrix));
    }

    @Test
    void testEmptyMatrix() {
        int[][] matrix = new int[0][0];
        assertEquals(-1, Lab7.rowWithMaxSum(matrix));
    }

    @Test
    void testNullMatrix() {
        int[][] matrix = null;
        assertEquals(-1, Lab7.rowWithMaxSum(matrix));
    }

    @Test
    void testZeroSumRows() {
        int[][] matrix = {
                {0, 0, 0},
                {0, 0, 0},
                {0, 0, 0}
        };
        assertEquals(0, Lab7.rowWithMaxSum(matrix)); // Все суммы равны 0
    }
}