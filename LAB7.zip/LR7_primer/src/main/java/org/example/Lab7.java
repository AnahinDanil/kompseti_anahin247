package org.example;

public class Lab7 {
    public static int rowWithMaxSum(int[][] matrix) {
        if (matrix == null || matrix.length == 0) {
            return -1; // Возвращаем -1, если матрица пустая
        }

        int maxSum = Integer.MIN_VALUE;
        int rowIndex = -1;

        for (int i = 0; i < matrix.length; i++) {
            int sum = 0;
            for (int value : matrix[i]) {
                sum += value;
            }
            if (sum > maxSum) {
                maxSum = sum;
                rowIndex = i;
            }
        }

        return rowIndex;
    }

}
