package org.junit;
public class MatrixTasks {
    public static int[][] createMatrixA(int N, int M) {
        if (N <= 0 || M <= 0) {
            return new int[0][0];
        }
        int[][] matrix = new int[N][M];
        for (int i = 0; i < N; i++) {
            int value = 2 * (i + 1);
            for (int j = 0; j < M; j++) {
                matrix[i][j] = value;
            }
        }
        return matrix;
    }
    public static int[][] createMatrixD(int N, int M) {
        if (N <= 0 || M <= 0) {
            return new int[0][0];
        }
        int[][] matrix = new int[N][M];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < M; j++) {
                matrix[i][j] = i * j;
            }
        }
        return matrix;
    }
    public static int[][] createMatrixE(int N, int M) {
        if (N <= 0 || M <= 0) {
            return new int[0][0];
        }
        int[][] matrix = new int[N][M];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < M; j++) {
                matrix[i][j] = (i + j) % 3;
            }
        }
        return matrix;
    }
}