package org.junit;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class MatrixTasksTest {

    @Test
    void testCreateMatrixA_normalCase() {
        int[][] expected = {
                {2, 2, 2},
                {4, 4, 4},
                {6, 6, 6}
        };
        Assertions.assertArrayEquals(expected, MatrixTasks.createMatrixA(3, 3));
    }

    @Test
    void testCreateMatrixA_2x4() {
        int[][] expected = {
                {2, 2, 2, 2},
                {4, 4, 4, 4}
        };
        Assertions.assertArrayEquals(expected, MatrixTasks.createMatrixA(2, 4));
    }

    //  ТЕСТЫ ДЛЯ ЗАДАНИЯ 2

    @Test
    void testCreateMatrixD_normalCase() {
        int[][] expected = {
                {0, 0, 0},
                {0, 1, 2},
                {0, 2, 4}
        };
        Assertions.assertArrayEquals(expected, MatrixTasks.createMatrixD(3, 3));
    }

    @Test
    void testCreateMatrixD_4x2() {
        int[][] expected = {
                {0, 0},
                {0, 1},
                {0, 2},
                {0, 3}
        };
        Assertions.assertArrayEquals(expected, MatrixTasks.createMatrixD(4, 2));
    }

    //  ТЕСТЫ ДЛЯ ЗАДАНИЯ 3

    @Test
    void testCreateMatrixE_normalCase() {
        int[][] expected = {
                {0, 1, 2},
                {1, 2, 0},
                {2, 0, 1}
        };
        Assertions.assertArrayEquals(expected, MatrixTasks.createMatrixE(3, 3));
    }

    @Test
    void testCreateMatrixE_2x4() {
        int[][] expected = {
                {0, 1, 2, 0},
                {1, 2, 0, 1}
        };
        Assertions.assertArrayEquals(expected, MatrixTasks.createMatrixE(2, 4));
    }
}