package org.example;

import java.util.Random;

public class Lab5 {

    public static double step(double osn, int nn) {
        if (nn == 0) {
            return 1;
        }
        double st = 1;
        for (int i = 1; i <= Math.abs(nn); i++) {
            st = st * osn;
        }
        return nn < 0 ? 1 / st : st;
    }

    public static double summaMassiv(double[] mas) {
        if (mas == null) {
            return 0;
        }
        double sum = 0;
        for (int i = 0; i < mas.length; i++) {
            sum = sum + mas[i];
        }
        return sum;
    }

    public static double sumFormula(double[] y, int m, double a, double b) {
        if (y == null || m <= 0 || y.length < m) {
            return 0;
        }
        double ab = a + b;
        double abPowerM = step(ab, m);
        double sum = 0;
        for (int j = 0; j < m; j++) {
            sum = sum + (abPowerM - y[j]);
        }
        return sum;
    }

    public static double getResult(double[] y, int n, int m, double a, double b) {
        if (y == null || n <= 0 || m <= 0 || y.length < m) {
            return 0;
        }
        double ab = a + b;
        double numerator = step(ab, n);
        double denominator = sumFormula(y, m, a, b);
        if (denominator == 0) {
            return 0;
        }
        return numerator / denominator;
    }

    public static double getResult(double[] y, int n, double a, double b) {
        int m = y.length;
        return getResult(y, n, m, a, b);
    }
}