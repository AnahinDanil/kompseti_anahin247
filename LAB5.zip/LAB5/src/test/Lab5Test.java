import org.example.Lab5;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Lab5Test {

    private static final double DELTA = 0.0001;

    @Test
    void testGetResult_TypicalCase() {
        double[] y = {1.0, 2.0, 3.0};
        double expected = 4.0 / 18.0;
        assertEquals(expected, Lab5.getResult(y, 2, 3, 1.0, 1.0), DELTA);
    }

    @Test
    void testGetResult_NegativeY() {
        double[] y = {-1.0, -2.0, -3.0};
        double expected = 4.0 / 30.0;
        assertEquals(expected, Lab5.getResult(y, 2, 3, 1.0, 1.0), DELTA);
    }

    @Test
    void testGetResult_NegativeAbEven() {
        double[] y = {1.0, 2.0, 3.0};
        double expected = 1.0 / -9.0;
        assertEquals(expected, Lab5.getResult(y, 2, 3, -2.0, 1.0), DELTA);
    }

    @Test
    void testGetResult_NegativeAbOdd() {
        double[] y = {1.0, 2.0, 3.0};
        double expected = -1.0 / -9.0;
        assertEquals(expected, Lab5.getResult(y, 3, 3, -2.0, 1.0), DELTA);
    }

    @Test
    void testGetResult_ZeroDenominator() {
        double[] y = {8.0, 8.0, 8.0};
        assertEquals(0.0, Lab5.getResult(y, 2, 3, 1.0, 1.0), DELTA);
    }

    @Test
    void testGetResult_SingleElement() {
        double[] y = {5.0};
        double expected = 9.0 / -2.0;
        assertEquals(expected, Lab5.getResult(y, 2, 1, 2.0, 1.0), DELTA);
    }

    @Test
    void testGetResult_OverloadedMethod() {
        double[] y = {1.0, 2.0, 3.0};
        double expected = 4.0 / 18.0;
        assertEquals(expected, Lab5.getResult(y, 2, 1.0, 1.0), DELTA);
    }

    @Test
    void testGetResult_EmptyArray() {
        double[] y = {};
        assertEquals(0.0, Lab5.getResult(y, 2, 0, 1.0, 1.0), DELTA);
    }

    @Test
    void testGetResult_NullArray() {
        assertEquals(0.0, Lab5.getResult(null, 2, 3, 1.0, 1.0), DELTA);
    }

    @Test
    void testGetResult_FractionalValues() {
        double[] y = {2.0, 3.0, 4.0};
        double expected = 0.25 / -8.625;
        assertEquals(expected, Lab5.getResult(y, 2, 3, 0.25, 0.25), DELTA);
    }
}